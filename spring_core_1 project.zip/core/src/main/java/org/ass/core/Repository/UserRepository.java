package org.ass.core.Repository;

import org.ass.core.dto.UserDto;
import org.ass.core.entity.UserEntity;
import org.ass.core.util.ConnectionPropertiesUtil;
import org.ass.core.util.SessionFactoryUtil;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UserRepository {
	
//	public void saveOrUpdateUseDetails( UserEntity userEntity) {
////	 Configuration cfg= new Configuration();
////	  cfg.setProperties(ConnectionPropertiesUtil.getMysqlDbProperties());
////	  cfg.addAnnotatedClass(UserEntity.class);
////	  SessionFactory SessionFactory = cfg.buildSessionFactory();
//		SessionFactory SessionFactory =SessionFactoryUtil.getSessionFactory();
//		Session Session = SessionFactory.openSession();
//	  Transaction Transaction = Session.beginTransaction();
//	  Session.save(userEntity);
//	  Transaction.commit();
//	}
//	
//	public UserEntity findById(long id) {
//	
//		 SessionFactory SessionFactory = SessionFactoryUtil.getSessionFactory();
//			
//			Session session = SessionFactory.openSession();
//			return session.get(UserEntity.class, id);
//	}
//	private void update(UserDto userDto) {
//		
//		UserEntity userEntity = findById(userDto.getAltkey());
//		if(userEntity!=null) {
//			userEntity.setName(userDto.getName());
//			userEntity.setCity(userDto.getCity());
//			userEntity.setCountry(userDto.getCountry());
//			userEntity.setPincode(userDto.getPinCode());
//			
//			saveOrUpdateUseDetails(userEntity);
//	}
//	private void delete() {
//		
//     // delete logic
//	}

	public void saveOrUpdateUseDetails( UserEntity userEntity) {
		// Configuration cfg= new Configuration();
		 // cfg.setProperties(ConnectionPropertiesUtil.getMysqlDbProperties());
		 // cfg.addAnnotatedClass(UserEntity.class);
		//  SessionFactory SessionFactory = cfg.buildSessionFactory();
			 SessionFactory SessionFactory =SessionFactoryUtil.getSessionFactory();
		  Session Session = SessionFactory.openSession();
		  Transaction Transaction = Session.beginTransaction();
		  Session.merge(userEntity);
		  Transaction.commit();
		}
		
		public UserEntity  findById(long id) {
		//	Configuration cfg = new Configuration();
		//	cfg.setProperties(ConnectionPropertiesUtil.getMysqlDbProperties());
		//	cfg.addAnnotatedClass(UserEntity.class);
		// SessionFactory sessionFactory= cfg.buildSessionFactory();
			
			 SessionFactory SessionFactory = SessionFactoryUtil.getSessionFactory();
		
			Session session = SessionFactory.openSession();
			return session.get(UserEntity.class, id);
			//return userEntity;
		}
		
		
		public void update(UserDto userDto) {
		
			UserEntity userEntity = findById(userDto.getAltkey());
			if(userEntity!=null) {
				userEntity.setName(userDto.getName());
				userEntity.setCity(userDto.getCity());
				userEntity.setCountry(userDto.getCountry());
				userEntity.setPincode(userDto.getPinCode());
				
				saveOrUpdateUseDetails(userEntity);
			}
			
			/*Configuration cfg = new Configuration();
	         cfg.setProperties(ConnectionPropertiesUtil.getMysqlDbProperties());
	         cfg.addAnnotatedClass(UserEntity.class);
	          SessionFactory sessionFactory = cfg.buildSessionFactory();
	          Session session = sessionFactory.openSession();
	          Transaction transaction = session.beginTransaction();
	          session.merge(userEntity);
	          transaction.commit();*/
		}
		private void delete() {
			
	     // delete logic
		}
}
