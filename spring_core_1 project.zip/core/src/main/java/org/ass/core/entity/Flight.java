package org.ass.core.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;



@Entity
@Table(name="flight_info")

public class Flight implements Serializable {
	

	@Id
	@GenericGenerator(name="auto_gen",strategy="increment")
	@GeneratedValue(generator="auto_gen")
	@Column(name ="alt_key")
	private long altkey;

	@Column(name ="name")
	private String name;

	@Column(name ="numOf_Seats")
	private String numOfSeats;

	@Column(name ="price")
	private  double  price;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="fight_id")

	private List<Airhostes>airhostressesList;

	public long getAltkey() {
		return altkey;
	}

	public void setAltkey(long altkey) {
		this.altkey = altkey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumOfSeats() {
		return numOfSeats;
	}

	public void setNumOfSeats(String numOfSeats) {
		this.numOfSeats = numOfSeats;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public List<Airhostes> getAirhostressesList() {
		return airhostressesList;
	}

	public void setAirhostressesList(List<Airhostes> airhostressesList) {
		this.airhostressesList = airhostressesList;
	}
		

}
