package org.ass.core.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="team_info")
public class Team implements Serializable{
	
	@Id
	@GenericGenerator(name="auto_gen",strategy="increment")
	@GeneratedValue(generator="auto_gen")
	@Column(name ="alt_key")
	private long altkey;
	
	@Column(name ="name")
    private String name;
	
	@Column(name ="team_size")
	private String teamsize;
	
	@Column(name ="team_type")
	private String teamtype;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name ="forigen_key")
	private Captian captian;

	public long getAltkey() {
		return altkey;
	}

	public void setAltkey(long altkey) {
		this.altkey = altkey;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeamsize() {
		return teamsize;
	}

	public void setTeamsize(String teamsize) {
		this.teamsize = teamsize;
	}

	public String getTeamtype() {
		return teamtype;
	}

	public void setTeamtype(String teamtype) {
		this.teamtype = teamtype;
	}

	public Captian getCaptian() {
		return captian;
	}

	public void setCaptian(Captian captian) {
		this.captian = captian;
	}
	
	
	
	

}
