package org.ass.core;

import java.util.ArrayList;
import java.util.List;

import org.ass.core.Repository.AssociationRepository;
import org.ass.core.Repository.UserHqlRepository;
import org.ass.core.Repository.UserRepository;
import org.ass.core.entity.Airhostes;
import org.ass.core.entity.Captian;
import org.ass.core.entity.Flight;
import org.ass.core.entity.Team;
import org.ass.core.entity.UserEntity;
import org.hibernate.engine.profile.Association;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       /* System.out.println( "Hello World!" );
        
        UserEntity userEntity = new UserEntity();
        userEntity.setAltkey(127);
        userEntity.setName("Gyan");
        userEntity.setEmail("gyan@123");
        userEntity.setPassword("127");
        userEntity.setCity("Ranchi");
        userEntity.setPincode("835302");         
        userEntity.setContactNumber("6207365455");
        userEntity.setCountry("India");
        
        UserRepository repository = new UserRepository();
       // repository.save(userEntity);
        
        UserHqlRepository hqlRepository = new UserHqlRepository();
        List<UserEntity> userEntityList = hqlRepository.findAll();
        userEntityList.forEach(each->{
      	  System.out.println(each);
        });*/
    	
    	/*Team team = new Team();
    	team.setName("Indian cricket");
    	team.setTeamsize("11");
    	team.setTeamtype("cricket");
    	
    	Captian captian = new Captian();
    	captian.setCaptianName("kholi");
    	captian.setAge("35");
    	captian.setEmail("k@123");
    	
    	team.setCaptian(captian);
    	AssociationRepository repository2= new AssociationRepository();
    	repository2.saveTeamDetails(team);*/
    	
    	  Airhostes airhostes = new Airhostes();
          airhostes.setName("Madhuri");
          airhostes.setAge("40");
          
          Airhostes airhostes1 = new Airhostes();
          airhostes1.setName("SriDevi");
          airhostes1.setAge("50");
          
          Airhostes airhostes2 = new Airhostes();
          airhostes2.setName("Kajol");
          airhostes2.setAge("48");
          
          ArrayList<Airhostes> arraylist = new ArrayList<Airhostes>();
          arraylist.add(airhostes);
          arraylist.add(airhostes1);
          arraylist.add(airhostes2);
          
          Flight flight = new Flight();
      	flight.setName("AirIndia");
      	flight.setPrice(10000);
      	flight.setNumOfSeats("100");
      	flight.setAirhostressesList(arraylist);
      	
          
          
         
        AssociationRepository repository2 = new AssociationRepository();
        repository2.saveFlightDetails(flight);
         
    }
}
