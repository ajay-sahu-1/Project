package org.ass.core.util;

import org.hibernate.cfg.Configuration;
import org.ass.core.entity.Airhostes;
import org.ass.core.entity.Captian;
import org.ass.core.entity.Flight;
import org.ass.core.entity.Team;
import org.ass.core.entity.UserEntity;
import org.hibernate.SessionFactory;

public class SessionFactoryUtil {

private  static SessionFactory sessionFactory=null;
	
	public static SessionFactory getSessionFactory() {
		if(sessionFactory==null) {
			Configuration cfg = new Configuration();
			cfg.setProperties(ConnectionPropertiesUtil.getMysqlDbProperties());
			cfg.addAnnotatedClass(UserEntity.class);
			cfg.addAnnotatedClass(Team.class);
			cfg.addAnnotatedClass(Captian.class);
			cfg.addAnnotatedClass(Flight.class);
			cfg.addAnnotatedClass(Airhostes.class);
			SessionFactory sessionFactory= cfg.buildSessionFactory();
		}
		return sessionFactory;
	}
}
