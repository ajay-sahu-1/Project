package cookieImp2;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/cooklogin1")
public class CookClass1 extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		String user = req.getParameter("user");
		String password = req.getParameter("password");
		
		System.out.println(user);
		System.out.println(password);
		
		Cookie cookie = new Cookie("user", user);
		Cookie cookie1 = new Cookie("password", password);
		
		
		resp.addCookie(cookie);
		resp.addCookie(cookie1);
		
		resp.sendRedirect("cooklogin2");
	}

}
