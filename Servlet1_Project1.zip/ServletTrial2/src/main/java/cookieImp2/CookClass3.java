package cookieImp2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cooklogin3")
public class CookClass3 extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		Cookie [] arr = req.getCookies();
		String user = null;
		String password = null;
		
		for(Cookie c:arr)
		{
			if(c.getName().equals("user"))
			{
				user =c.getValue();
				
			}
			if (c.getName().equals("password"))
			{
				password = c.getValue();
			}
		}
			System.out.println(user);
			System.out.println(password);
			
			
			PrintWriter writer = resp.getWriter();
			writer.println(user);
			writer.println(password);
		
	}

}
