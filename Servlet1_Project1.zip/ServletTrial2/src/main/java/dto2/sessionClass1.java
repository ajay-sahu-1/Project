package dto2;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/Sess1")
public class sessionClass1 extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    
		String id = req.getParameter("user");
		String name = req.getParameter("password");
		
		System.out.println(user);
		System.out.println(password);
		
		HttpSession session = req.getSession();
		session.setAttribute("user", user);
		session.setAttribute("password", password);
		
		resp.sendRedirect("Sess2");

	}

}
