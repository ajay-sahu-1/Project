package sessionWithRD;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/trialform2")
public class ReqClass2 extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

          HttpSession S2 = req.getSession();
          String id = (String)S2.getAttribute("id");
          String name = (String)S2.getAttribute("name");
          String email = (String)S2.getAttribute("email");

          
          PrintWriter out = resp.getWriter();
//         out.println(id);
//          out.println(name);
//
//          out.println(email);

		RequestDispatcher rd = req.getRequestDispatcher("/trialdisplay.jsp");
		req.setAttribute("class","Jee class ");
		rd.forward(req, resp);
		
		
          


}

}
