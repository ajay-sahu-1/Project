package com.requestDispatch2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/rd5")

public class RDClass5 extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("class servlet 2");
	PrintWriter writer=resp.getWriter();
	writer.println("reached servletc2");
	writer.println("<h1>"+req.getParameter("id")+"</h1>");
	writer.println("<h1>"+req.getParameter("name")+"</h1>");
	
	RequestDispatcher rd=req.getRequestDispatcher("rd6");
	rd.include(req, resp);
		
		
	}

}
