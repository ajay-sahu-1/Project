package login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")

public class login1 extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//System.out.println(" welcome to home page");
		
		String user = req.getParameter("user");
		String pass = req.getParameter("pass");
		
		if(user.equals("ajay") && pass.equals("1234"))
			
		{
			req.setAttribute("password", pass.toUpperCase());
			req.getRequestDispatcher("login2").forward(req, resp);
			
		}else {
			String invalid = "Invalid";
			req.setAttribute("invalid", invalid.toUpperCase());
			req.getRequestDispatcher("invalid").forward(req, resp);
		}
		
		
		

	}
}
