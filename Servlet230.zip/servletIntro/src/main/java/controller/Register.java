package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class Register extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String name = req.getParameter("name");
		//String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");
		String DOB = req.getParameter("DOB");
		String Qualification= req.getParameter("Qualification");
		
		System.out.println(name);
		//System.out.println(email);
		System.out.println(phone);
		System.out.println(address);
		System.out.println(DOB);
		System.out.println(Qualification);
		
		
		PrintWriter writer = res.getWriter();
		
		writer.write("<body bgcolor=pink>");
		 writer.write("<h1>"+"Thank Yor for registration your data is recieved"+"</h1>");
		
	}
	
		
	}


