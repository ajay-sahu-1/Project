package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebServlet;
//@WebServlet("/login")
public class Login  extends GenericServlet{

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
//		String userName = req.getParameter("user");
//		String password = req.getParameter("pass");
//		
//		if(userName.equals("ajay") && password.equals("1234"))
//			
//		{
//			
//			System.out.println("valid");
//			PrintWriter writer = res.getWriter();
//			writer.write("<body bgcolor=pink>");
//			writer.println("<h1>"+"Welcome to Username Have a great day"+"</h1>");
//			
//			
//		}else {
//			String invalid = "Invalid";
//			
//			System.out.println("Invalid");
//			PrintWriter writer = res.getWriter();
//			writer.write("<body bgcolor=pink>");
//			
//			writer.println("<h1>"+"Invalid UserName and password"+"</h1>");
//			
//			
//		}
//		
//	}
		PrintWriter writer = res.getWriter();

		if(req.getParameter("name").equals("ajay")&&
				req.getParameter("password").equals("1234")) {
			
			writer.println("<h1>"+"Welcome to Username Have a great day"+"</h1>");
		}
		else {
			writer.println("<h1>"+"Invalid UserName and password"+"</h1>");
			
		}
			
		}
		
}
