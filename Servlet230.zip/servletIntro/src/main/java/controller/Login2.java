package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login2")
public class Login2  extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter writer = resp.getWriter();                           

		if(req.getParameter("name").equals("ajay")&&
				req.getParameter("password").equals("1234")) {
			
			writer.println("<h1>"+"Welcome Ajay  Have a great day"+"</h1>");
		}
		else {
			writer.println("<h1>"+"Invalid UserName and password"+"</h1>");
			
		}
	}
		@Override
		protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			// TODO Auto-generated method stub
			System.out.println("get method executed");
			
		
			
		
		
		
		
	}
}
