package controller;

import java.io.IOException;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.aj.studentdata.dto.Student;

public class Save extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
//		
		
		System.out.println(name);
		System.out.println(email);
		System.out.println(phone);
//		
		
		
		System.out.println("service() from save class");
		
		ServletContext context = getServletContext();
		String value = context.getInitParameter("one");
		System.out.println(value);
		String ss = new String ("new String");
		context.setAttribute("str",ss);
		
		ServletConfig config = getServletConfig();
		String con = config.getInitParameter("two");
		System.out.println(con);
	}
	public void display() {
		System.out.println("");
	}

}
