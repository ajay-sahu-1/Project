package com.aj.studentdata.dto;

public class Student {

}
