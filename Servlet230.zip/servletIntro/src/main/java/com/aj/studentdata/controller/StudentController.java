package com.aj.studentdata.controller;

public class StudentController {

}
