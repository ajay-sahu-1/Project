﻿using EntityFrameworkSP_Demo.Data;
using EntityFrameworkSP_Demo.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EntityFrameworkSP_Demo.Repositories
{
    public class ProductService : IProductService
    {
        private readonly DbContextClass context;

        public ProductService(DbContextClass context)
        {
            this.context = context;
        }

        public async Task<List<Product>> GetProductListAsync()
        {
            return await context.Products
                .FromSqlRaw("exec GetProductList")
                .ToListAsync();
        }

        public async Task<IEnumerable<Product>> GetProductByIdAsync(int ProductId)
        {
            var param = new SqlParameter("@ProductId", ProductId);

            var productDetails = await context.Products
                .FromSqlRaw("exec GetProductById @ProductId", param)
                .ToListAsync();

            return productDetails;
        }

        public async Task<int> AddProductAsync(Product product)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProductName", product.ProductName),
                new SqlParameter("@ProductDescription", product.ProductDescription),
                new SqlParameter("@ProductPrice", product.ProductPrice),
                new SqlParameter("@ProductStock", product.ProductStock)
            };

            var result = await context.Database
                .ExecuteSqlRawAsync("exec AddNewProduct @ProductName, @ProductDescription, @ProductPrice, @ProductStock", parameters.ToArray());

            return result;
        }

        public async Task<int> UpdateProductAsync(Product product)
        {
            var parameters = new List<SqlParameter>
            {
                new SqlParameter("@ProductId", product.ProductId),
                new SqlParameter("@ProductName", product.ProductName),
                new SqlParameter("@ProductDescription", product.ProductDescription),
                new SqlParameter("@ProductPrice", product.ProductPrice),
                new SqlParameter("@ProductStock", product.ProductStock)
            };

            var result = await context.Database
                .ExecuteSqlRawAsync("exec UpdateProduct @ProductId, @ProductName, @ProductDescription, @ProductPrice, @ProductStock", parameters.ToArray());

            return result;
        }

        public async Task<int> DeleteProductAsync(int ProductId)
        {
            return await context.Database
                .ExecuteSqlInterpolatedAsync($"exec DeleteProductById {ProductId}");
        }
    }
}
