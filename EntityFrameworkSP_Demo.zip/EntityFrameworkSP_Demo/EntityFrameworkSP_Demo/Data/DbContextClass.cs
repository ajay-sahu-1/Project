﻿using EntityFrameworkSP_Demo.Entities;
using Microsoft.EntityFrameworkCore;


namespace EntityFrameworkSP_Demo.Data
{
    public class DbContextClass  :  DbContext
    {
        public DbContextClass(DbContextOptions<DbContextClass> options) : base(options) { }
       

        public DbSet<Product> Products { get; set; }

    }
}
