﻿using System;
using System.Collections.Generic;

namespace COREWEBAPI.Models
{
    public partial class Student
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
        public string Address { get; set; } = null!;
        public string EmaiId { get; set; } = null!;
        public decimal PhoneNo { get; set; }
        public int Standard { get; set; }
    }
}
