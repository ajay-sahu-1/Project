﻿using COREWEBAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace COREWEBAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentApiController : ControllerBase
    {
        private readonly COREWEBAPI_DBContext context;

        public StudentApiController(COREWEBAPI_DBContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Student>>> GetStudents()
        {
            var data = await context.Students.ToListAsync();
            return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task <ActionResult<Student>>GetStudents(int id)
        {
            var student = await context.Students.FindAsync(id);
            if (student == null)
            {
                return NotFound();
            }

            return Ok(student);



        }
        [HttpPost]

        public async Task <ActionResult<Student>> crateStudent(Student student)
        {
            await context.Students.AddAsync(student);
              context.SaveChanges();
            return Ok(student);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<Student>> updateStudent(int id ,Student student)
        {
            if(id! == student.Id)
            {
                return BadRequest();
            }
            context.Entry(student).State = EntityState.Modified;
            await context.SaveChangesAsync();
            return Ok(student);
        }
        [HttpDelete("{id}")]
        public async Task<ActionResult<Student>> DeleteStudent(int id)
        {
            var stu = await context.Students.FindAsync(id);
            if (stu == null)
            {
                return NotFound();
            }
            context.Students.Remove(stu);
            await context.SaveChangesAsync();
            return Ok(stu);
        }
    }
}
