package org.ass.ums.controller;

import org.ass.ums.dto.RegisterDto;
import org.ass.ums.entity.RegisterEntity;
import org.ass.ums.service.impl.RegisterServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//@Component()
@Controller//to create the object of a class
public class RegisterController {//controller class
	
	@Autowired// injecting the required reference (dependency injection) in the class
	private RegisterServiceImpl registerServiceImpl;
	
	@RequestMapping(value = "/saveUserDetails") //Uri(universal resource locater or identifier) has to be unique
	public ModelAndView saveUserDetails(RegisterEntity registerEntity) {
		System.out.println(registerEntity);
		registerServiceImpl.processUserInfo(registerEntity);
		return new ModelAndView("index.jsp");
		
	}
	
	public RegisterController(){
		System.out.println("executed");
	}

}
