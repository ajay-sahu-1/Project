package com.abhi.HibernateProject.repository;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.abhi.HibernateProject.entity.Customer;
import com.abhi.HibernateProject.util.SessionFactoryUtil;

public class BankRepository {
	public void saveCutomer(Customer customer) {
		SessionFactory factory = SessionFactoryUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.merge(customer);
		transaction.commit();
	}
}
