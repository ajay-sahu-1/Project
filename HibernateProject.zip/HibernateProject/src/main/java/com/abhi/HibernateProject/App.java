package com.abhi.HibernateProject;

import java.util.ArrayList;
import java.util.List;

import com.abhi.HibernateProject.entity.BankAccount;
import com.abhi.HibernateProject.entity.Customer;
import com.abhi.HibernateProject.repository.BankRepository;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
		Customer customer = new Customer();
		customer.setName("Legain2");
		customer.setAddress("GTK2");
		BankAccount b1 = new BankAccount();
		b1.setCustomer(customer);
		b1.setName("SBI1");
		b1.setAccountNumber("sdas5555ss3235");
		BankAccount b2 = new BankAccount();
		b2.setCustomer(customer);
		b2.setName("ICICIfsf");
		b2.setAccountNumber("21200021sds210dfdf");
		BankAccount b3 = new BankAccount();
		b3.setCustomer(customer);
		b3.setName("CANARAere");
		b3.setAccountNumber("2686dsds26errwe");

		List<BankAccount> list = new ArrayList<BankAccount>();
		list.add(b1);
		list.add(b2);
		list.add(b3);
		
		
		customer.setAccounts(list);

		BankRepository repo = new BankRepository();
		repo.saveCutomer(customer);
	}
}
