package com.abhi.HibernateProject.util;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.abhi.HibernateProject.entity.BankAccount;
import com.abhi.HibernateProject.entity.Course;
import com.abhi.HibernateProject.entity.Customer;
import com.abhi.HibernateProject.entity.Student;

public class SessionFactoryUtil {
	private static SessionFactory sessionFactory;
	static {
		Configuration cfg = new Configuration();
		Properties properties = MysqlConnectionPropertiesUtil.getConnectionProperties();
		cfg.setProperties(properties);
		cfg.addAnnotatedClass(Customer.class);
		cfg.addAnnotatedClass(BankAccount.class);
		cfg.addAnnotatedClass(Course.class);
		cfg.addAnnotatedClass(Student.class);
		sessionFactory = cfg.buildSessionFactory();
	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
