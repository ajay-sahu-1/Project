package com.abhi.HibernateProject.repository;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.abhi.HibernateProject.entity.Student;
import com.abhi.HibernateProject.util.SessionFactoryUtil;

public class StudenntRepository {

	public void saveStudent(List<Student> slist) {
		SessionFactory factory = SessionFactoryUtil.getSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		for (Student s : slist) {
			session.save(s);
		}
		transaction.commit();

	}
}
