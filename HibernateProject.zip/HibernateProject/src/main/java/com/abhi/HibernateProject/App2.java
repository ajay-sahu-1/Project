package com.abhi.HibernateProject;

import java.util.ArrayList;
import java.util.List;

import com.abhi.HibernateProject.entity.Course;
import com.abhi.HibernateProject.entity.Student;
import com.abhi.HibernateProject.repository.StudenntRepository;

public class App2 {
	public static void main(String[] args) {
		Course course = new Course();
		course.setName("JAVA");
		course.setCredits("25");
		Course course1 = new Course();
		course1.setName("JEE");
		course1.setCredits("25");
		Course course2 = new Course();
		course2.setName("Frameworks");
		course2.setCredits("25");
		List<Course> list = new ArrayList<>();
		list.add(course);
		list.add(course1);
		list.add(course2);

		Student s = new Student();
		s.setName("Legain");
		s.setEmailId("lee@gamil.com");
		s.setCourses(list);
		Student s1 = new Student();
		s1.setName("Karma");
		s1.setEmailId("kar@gamil.com");
		s1.setCourses(list);
		Student s2 = new Student();
		s2.setName("Prescilla");
		s2.setEmailId("pree@gamil.com");
		s2.setCourses(list);
		
		List<Student> slist= new ArrayList<>();
		slist.add(s);
		slist.add(s1);
		slist.add(s2);
		
		course1.setStudents(slist);
		course2.setStudents(slist);
		course.setStudents(slist);

		StudenntRepository repository = new StudenntRepository();
		repository.saveStudent(slist);

	}

}
