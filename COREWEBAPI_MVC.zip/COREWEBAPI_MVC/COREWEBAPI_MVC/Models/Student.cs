﻿namespace COREWEBAPI_MVC.Models
{
    public class Student
    {
        public int id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string emaiId { get; set; }
        public long phoneNo { get; set; }
        public int standard { get; set; }
    }
}
