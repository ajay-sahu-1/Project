﻿using COREWEBAPI_MVC.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text;

namespace COREWEBAPI_MVC.Controllers
{
    public class StudentController : Controller
    {
        private string url = "https://localhost:7173/api/StudentApi/";
        private HttpClient client = new HttpClient();

        [HttpGet]
        public IActionResult Index()
        {
            List<Student> students = new List<Student>();
            HttpResponseMessage response = client.GetAsync(url).Result;
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<List<Student>>(result);
                if (data != null)
                {
                    students = data;
                }
            }
            return View(students);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Student st)
        {
            string data = JsonConvert.SerializeObject(st);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage response = client.PostAsync(url, content).Result;
            if (response.IsSuccessStatusCode)
            {
                TempData["messegeInserted"] = "Student Information is Added...!";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            Student student = new Student();
            HttpResponseMessage response = client.GetAsync(url+id).Result;
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Student>(result);
                if(data!= null)
                {
                    student = data;
                }
            }
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(Student st)
        {
            string data = JsonConvert.SerializeObject(st);
            StringContent content = new StringContent(data, Encoding.UTF8, "application/Json");
            HttpResponseMessage response = client.PutAsync(url + st.id, content).Result;
            if (response.IsSuccessStatusCode)
            {
                TempData["messegeUpdated"] = "Student Information is Updated...!";
                return RedirectToAction("Index");
            }
            return View();
        }

        [HttpGet]
        public IActionResult Details(int Id)
        {
            Student st = new Student();
            HttpResponseMessage response = client.GetAsync(url + Id).Result;
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Student>(result);
                if(data!=null)
                {
                    st = data;
                }
            }
            return View(st);
        }

        [HttpGet]

        public IActionResult Delete(int Id)
        {
            Student st = new Student();
            HttpResponseMessage response = client.GetAsync(url + Id).Result;
            if (response.IsSuccessStatusCode)
            {
                string result = response.Content.ReadAsStringAsync().Result;
                var data = JsonConvert.DeserializeObject<Student>(result);
                if (data != null)
                {
                    st = data;
                }
            }
            return View(st);
        }
        [HttpPost,ActionName("Delete")]
        public IActionResult DeleteConfirmed(int Id)
        {
            //Student st = new Student();
            HttpResponseMessage response = client.DeleteAsync(url + Id).Result;
            if (response.IsSuccessStatusCode)
            {
                TempData["messegeDeleted"] = "Student Data Information is Deleted...!";
                    return RedirectToAction("Index");
            }

            return View();
        }
    }
    }
    

