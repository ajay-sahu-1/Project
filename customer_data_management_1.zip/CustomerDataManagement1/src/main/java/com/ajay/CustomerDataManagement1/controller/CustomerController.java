package com.ajay.CustomerDataManagement1.controller;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ajay.CustomerDataManagement1.dto.ResponseStructure;
import com.ajay.CustomerDataManagement1.entity.CustomerEntity;
import com.ajay.CustomerDataManagement1.service.CustomerService;


@RestController
public class CustomerController {
	
	 @Autowired
		private CustomerService service;
		
	    @PostMapping("/savecustomer")
		public @ResponseBody CustomerEntity saveCustomer(@RequestBody CustomerEntity entity) {
			return service.saveCustomer(entity);
		}
	    
	    @PutMapping("/updatecustomer")
	   	public @ResponseBody CustomerEntity updateCustomer(@RequestBody CustomerEntity entity) {
	   		return service.saveCustomer(entity);
	   	}
	    
	    @GetMapping("/getallcustomer")
		public @ResponseBody ResponseStructure<List<CustomerEntity>> getAllCustomer(){
			return service.getAllCustomer();
		}
	    
	    @GetMapping("/getcustomerbyid/{id}")
		public @ResponseBody CustomerEntity getCustomerDataById(@PathVariable("id") int id) {
			return service.getCustomerDataById(id);
		}
	    
	    @GetMapping("/deletecustomerbyid/{id}")
		public @ResponseBody CustomerEntity deleteCustomerDataById(@PathVariable("id")int id) {
			return service.deleteCustomerDataById(id);
		}
	    

	    @GetMapping("/getcustomerbyname/{name}")
	   	public @ResponseBody List<CustomerEntity> getCustomerDataById(@PathVariable("name") String name) {
	   		return service.getCustomerDataByName(name);
	   	}
		
	    @PostMapping("/validatecustomer")
	    public List<CustomerEntity> validdataCustomer(@RequestParam("name") String name,@RequestParam("email") String email){
	    	return service.validateCustomer(name, email);
	    }

}
