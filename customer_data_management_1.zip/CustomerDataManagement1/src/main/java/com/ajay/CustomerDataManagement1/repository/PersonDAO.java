package com.ajay.CustomerDataManagement1.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ajay.CustomerDataManagement1.entity.Person;

@Repository
public class PersonDAO {
	@Autowired
	private PersonRepository repository;
	
	public Person save (Person person) {
		
		return repository.save(person);
	}
	
	

}
