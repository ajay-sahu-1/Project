package com.ajay.CustomerDataManagement1.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.ajay.CustomerDataManagement1.dto.CustomerDTO;
import com.ajay.CustomerDataManagement1.dto.ResponseStructure;
import com.ajay.CustomerDataManagement1.entity.CustomerEntity;
import com.ajay.CustomerDataManagement1.repository.CustomerDAO;
import com.ajay.CustomerDataManagement1.repository.CustomerRepository;

@Service
public class CustomerService {
 
//	@Autowired
//	private CustomerRepository repository;
	@Autowired
	private CustomerDAO dao;
	
	public  ResponseStructure<Object> saveCustomer(CustomerDTO dto) {
		CustomerEntity customer = new CustomerEntity(dto);//cus
		CustomerEntity customer2 = dao.saveCustomer(customer);
		ResponseStructure<Object> res = new ResponseStructure<>();//customer
		
		res.setData(customer2);
		res.setStatusCode(HttpStatus.OK.value());
		res.setMessage("Customer data saved successfully");
		res.setTimeStamp(LocalDateTime.now());
		return res;
		
	}
	
	public CustomerEntity saveCustomer(CustomerEntity entity) {
		return dao.saveCustomer(entity);
	}
	public ResponseStructure<CustomerEntity> updateCustomer(CustomerEntity entity) {
		CustomerEntity cus = dao.saveCustomer(entity);
		ResponseStructure<CustomerEntity> res = new ResponseStructure<>();
		res.setData(cus);
		res.setStatusCode(HttpStatus.ACCEPTED.value());
		res.setTimeStamp(LocalDateTime.now());
		res.setMessage(HttpStatus.ACCEPTED.name());
		return res;
		
	}
	
	public ResponseStructure<List<CustomerEntity>> getAllCustomer(){
		List<CustomerEntity> list = dao.getAllCustomer();
		ResponseStructure<List<CustomerEntity>> res = new ResponseStructure<>();
	   if(list.size()!=0) {	
		   res.setStatusCode(HttpStatus.FOUND.value());
		   res.setData(list);
		   res.setTimeStamp(LocalDateTime.now());
		   res.setMessage("Customer entry found in data base");
	   }else {
		   res.setStatusCode(HttpStatus.NOT_FOUND.value());
		   res.setData(null);
		   res.setTimeStamp(LocalDateTime.now());
		   res.setMessage(" No Customer entry found in data base");
		   
	   }
	   return res;
	   
		}
	   
	
	
	public CustomerEntity getCustomerDataById(int id) {
		return dao.getCustomerDataById(id);
	}

	public CustomerEntity deleteCustomerDataById(int id) {
		return dao.deleteCustomerDataById(id);
	}

	public List<CustomerEntity> getCustomerDataByName(String name) {
		return dao.getCustomerDataByName(name);
	}
	
	public List<CustomerEntity> validateCustomer(String name,String email){
		return dao.validateCustomer(name, email);
	}
	
	
}
