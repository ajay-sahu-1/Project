package com.ajay.CustomerDataManagement1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ajay.CustomerDataManagement1.entity.Person;

public interface PersonRepository  extends JpaRepository<Person, Integer>{
	
	

}
