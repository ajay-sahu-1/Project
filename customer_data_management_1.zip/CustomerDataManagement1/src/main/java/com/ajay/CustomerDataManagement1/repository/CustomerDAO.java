package com.ajay.CustomerDataManagement1.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;

import com.ajay.CustomerDataManagement1.entity.CustomerEntity;

@Repository
public class CustomerDAO  {
	
	@Autowired
	private CustomerRepository repository;
	
	public CustomerEntity saveCustomer(CustomerEntity entity) {
		return repository.save(entity);
	}
	
	public List<CustomerEntity> getAllCustomer(){
		return repository.findAll();
	}
	
	public CustomerEntity getCustomerDataById(int id) {
		return repository.findById(id).orElse(
				new CustomerEntity(HttpStatus.NOT_FOUND.value()
						,HttpStatus.NOT_FOUND.name()
						,HttpStatus.NOT_FOUND.name()));
	}
	
	public CustomerEntity deleteCustomerDataById(int id) {
		CustomerEntity customer=getCustomerDataById(id);
		if(customer.getId()!=404) {
			repository.deleteById(id);
		}
		return customer;
	}
	
	public List<CustomerEntity> getCustomerDataByName(String name) {
		return repository.findByName(name);
		
	}

	public List<CustomerEntity> validateCustomer(String name,String email){
		return repository.validateCustomer(name, email);
	}


}
