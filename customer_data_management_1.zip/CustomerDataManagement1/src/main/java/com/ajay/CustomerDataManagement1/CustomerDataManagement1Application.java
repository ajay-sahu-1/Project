package com.ajay.CustomerDataManagement1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication

public class CustomerDataManagement1Application {

	public static void main(String[] args) {
		SpringApplication.run(CustomerDataManagement1Application.class, args);
	}

}
