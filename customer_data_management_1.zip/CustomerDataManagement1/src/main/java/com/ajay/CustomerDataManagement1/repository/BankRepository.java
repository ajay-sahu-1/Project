package com.ajay.CustomerDataManagement1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ajay.CustomerDataManagement1.entity.BankAccount;

public interface BankRepository extends JpaRepository<BankAccount, Integer> {

}
