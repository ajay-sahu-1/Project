package com.ajay.CustomerDataManagement1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerDataManagement1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
