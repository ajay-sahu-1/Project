# codingNinjasVanillaJsTODOLIST
A to Do List Made using Vanilla JS
Enter task in input and click on add button to input the task
Press the circle before the task to mark it completed.(Completed task have a line through)
Total Task is shown at bottom left
Clear All button is present at bottom right
Indivisual tasks can be deleted by hovering over the dustbin icon towards their right.